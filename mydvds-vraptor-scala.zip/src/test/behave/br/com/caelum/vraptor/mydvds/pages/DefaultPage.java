package br.com.caelum.vraptor.mydvds.pages;

import org.jbehave.web.selenium.WebDriverFactory;
import org.jbehave.web.selenium.WebDriverPage;

public class DefaultPage extends WebDriverPage {

    public DefaultPage(WebDriverFactory driver) {
        super(driver);
    }
    
}
